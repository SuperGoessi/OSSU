import this
import turtle as t

t.pensize(4)
t.pencolor('red')
t.forward(100)
t.right(90)
t.forward(100)
t.right(90)
t.forward(100)

t.mainloop()

