#ifndef SQUARE_H_INCLUDED
#define SQUARE_H_INCLUDED

int getSquareSides() {
    return 4;
}


#endif // SQUARE_H_INCLUDED
