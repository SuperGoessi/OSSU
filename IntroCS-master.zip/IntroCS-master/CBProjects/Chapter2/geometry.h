#ifndef GEOMETRY_H_INCLUDED
#define GEOMETRY_H_INCLUDED

#include "square.h"


#endif // GEOMETRY_H_INCLUDED
