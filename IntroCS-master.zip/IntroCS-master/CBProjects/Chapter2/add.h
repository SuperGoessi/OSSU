#ifndef ADD_H_INCLUDED
#define ADD_H_INCLUDED

int add(int x, int y);

#endif // ADD_H_INCLUDED
