#include "add.h"

namespace basicMath {
    int add(int x, int y){
        return x + y;
    }
}
