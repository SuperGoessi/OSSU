#ifndef GROWTH_H_INCLUDED
#define GROWTH_H_INCLUDED

namespace basicMath {
    inline constexpr double e {2.7};
}

#endif // GROWTH_H_INCLUDED
