namespace goo {
    int doSomething(int x, int y) {
    return x - y;
    }
}
