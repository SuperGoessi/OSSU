int g_x { 2 };
extern const int g_y {3};
