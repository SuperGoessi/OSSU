#ifndef CIRCLE_H_INCLUDED
#define CIRCLE_H_INCLUDED

namespace basicMath {
    inline constexpr double pi {3.14};
}

#endif // CIRCLE_H_INCLUDED
