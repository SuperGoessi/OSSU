namespace foo {
    int doSomething(int x, int y) {
    return x + y;
    }
}
