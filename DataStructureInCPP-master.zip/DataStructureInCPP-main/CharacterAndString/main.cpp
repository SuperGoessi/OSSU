#include <iostream>
#include <cctype>
#include <cstring>

using namespace std;

int main()
{
    char my_name[] {"Goessi"};
    cout <<my_name << endl;

    char your_name [9];
    //your_name = "Haha";
    strcpy(your_name, "Haha");

    char first_name[20];
    char last_name[20];
    //char full_name[50];
    //char temp[50];

    //cout <<first_name;




    return 0;
}
