#include <stdio.h>
#include <string>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc, char **argv)
{/*
	int *int_ptr {};
    double *double_ptr {nullptr};
    char *char_ptr {nullptr};
    string *string_ptr {nullptr};
    
    int *p;
    cout << "Value of p is: " << p << endl;
    cout << "Address of p is: " << &p << endl;
    cout << "sizeof of p is: " << sizeof(p) << endl;
    p = nullptr;
    cout << "Value of p is: " << p << endl;
    
    int score {100};
    double high_temp {100.7};
    int *score_ptr {nullptr};
    
    score_ptr = &score;
    cout << score_ptr << endl;
    cout << &score << endl; 
    
    int num{10};
    cout << "Value of num is: " << num << endl;
    cout << "sizeof of num is: " << sizeof(num) << endl;
    cout << "Address of num is: " << &num << endl;
    
    int *p;
    cout << "Value of p is: " << p << endl;
    cout << "Address of p is: " << &p << endl;
    cout << "sizeof of p is: " << sizeof(p) << endl;
    
    p = nullptr;
    cout << "Value of p is: " << p << endl;
    
    int score {100};
    int *score_ptr {&score};
    
    cout << *score_ptr << endl;
    
    *score_ptr = 200;
    cout << *score_ptr << endl;
    cout << score << endl;
    
    vector<string> stooges {"Larry", "Moe", "Curly"};
    vector<string> *vector_ptr {nullptr};
    
    vector_ptr = &stooges;
    
    cout << "First stooges: " << (*vector_ptr).at(0) << endl;
    
    cout << "Stooges: ";
    for (auto s: *vector_ptr)
        cout << s << " ";
    cout << endl;
    
    int *int_ptr {nullptr};
    int_ptr = new int;
    cout << int_ptr << endl;
    delete int_ptr;
    
    size_t size {0};
    double *temp_ptr {nullptr};
    cout << "How many temps?";
    cin >> size;
    temp_ptr = new double[size];
    cout << temp_ptr <<endl;
    delete [] temp_ptr;
    
    int scores[] {100, 95, 89};
    cout << "Value of scores:" << scores << endl;
    
    int *score_ptr {scores};
    cout << "Value of score_ptr:" << score_ptr << endl;
    
    cout << "\nArray subscript notation ----------" << endl;
    cout << scores[0] << endl;
    cout << scores[1] << endl;
    cout << scores[2] << endl;
    
    cout << "\nPointer subscript notation ----------" << endl;
    cout << score_ptr[0] << endl;
    cout << score_ptr[1] << endl;
    cout << score_ptr[2] << endl;
    
    cout << "\nPointer offset notation ----------" << endl;
    cout << *score_ptr << endl;
    cout << *(score_ptr + 1) << endl;
    cout << *(score_ptr + 2) << endl;
    
    cout << "\nArray offset notation ----------" << endl;
    cout << *scores << endl;
    cout << *(scores + 1) << endl;
    cout << *(scores + 2) << endl;
    
    
    int score {100};
    int *score_ptr {&score};
    
    cout << *score_ptr << endl;
    *score_ptr = 200;
    cout << *score_ptr << endl;
    cout << score << endl;
    
    double high_temp {100.7};
    double low_temp {37.4};
    double * temp_ptr {&high_temp};
    
    cout << *temp_ptr << endl;
    
    temp_ptr = &low_temp;
    
    cout << *temp_ptr << endl;
    
    
    int score {100};
    int *score_ptr {&score};
    
    cout << *score_ptr << endl;
    
    *score_ptr = 200;
    cout << *score_ptr <<endl;
    cout << score << endl;
    
    vector<string> stooges {"Larry", "Moe", "Curly"};
    vector<string> *vector_ptr {nullptr};
    
    vector_ptr = &stooges;
    
    cout << "First stooges: " << (*vector_ptr).at(0) << endl;
    
    cout << "Stooges: ";
    for(auto stooge: *vector_ptr)
        cout << stooge << " ";
    cout << endl;*/
    
    int scores[] {100, 95, 89};
    
    cout << "Value of scores: " << scores << endl;
    
    int *score_ptr{scores};
    cout << "Value of score_ptr: " << score_ptr << endl;
    
    cout << "\nArray subcript notation ----------" << endl;
    cout << scores[0] << endl;
    cout << scores[1] << endl;
    cout << scores[2] << endl;
    
    cout << "\nPointer subcript notation ---------" << endl;
    cout << score_ptr[0] << endl;
    cout << score_ptr[1] << endl;
    cout << score_ptr[2] << endl;
    
    cout << "\nPointer offset notation ----------" << endl;
    cout << *score_ptr << endl;
    cout << *(score_ptr + 1) << endl;
    cout << *(score_ptr + 2) << endl;
    
    cout << "\nArray offset notation ----------" << endl;
    cout << *scores << endl;
    cout << *(scores + 1) << endl;
    cout << *(scores + 2) << endl;
    
    return 0;
}
