#include <stdio.h>
#include <iostream>
using namespace std;

void double_data(int *int_ptr)
{
    *int_ptr *= 2;
}

int *largest_int(int *int_ptr1, int *int_ptr2)
{
    if(*int_ptr1 > *int_ptr2)
        return int_ptr1;
    else
        return int_ptr2;
}

int *creat_array(size_t size, int iniit_value = 0)
{
    int *new_array {nullptr};
    
    new_array = new int[size];
    for(size_t i{0}; i<size; ++i)
        *(new_array + i) = iniit_value;
    return new_array;
}

void display(const int *const array, size_t size)
{
    for(size_t i{0}; i <size; ++i)
        cout << array[i] << " ";
    cout << endl;
}

int main(int argc, char **argv)
{
	/*int high_score {100};
    int low_score {65};
    const int *score_ptr {&high_score};
    
    // *score_ptr = 86;
    score_ptr = &low_score;
    
    int *const score_ptr2 {&high_score};
    *score_ptr2 = 86;
    
    cout << *score_ptr << " " << *score_ptr2 << endl;
    
    int value {10};
    int *int_ptr {nullptr};
    
    cout << "Value: " << value << endl;
    double_data(&value);
    cout << "Value: " << value << endl;
    
    cout << "-----------" << endl;
    int_ptr = &value;
    double_data(int_ptr);
    cout << "Value: " << value << endl;
    
    int a{100};
    int b{200};
    
    int *largest_ptr {nullptr};
    largest_ptr = largest_int(&a, &b);
    cout << *largest_ptr << endl;
    
    int *my_array;
    my_array = creat_array(100, 20);
    
    delete [] my_array;*/
    
    int *my_array {nullptr};
    size_t size;
    int init_value {};
    
    cout << "\nHow many integers would you like to allocate?";
    cin >> size;
    cout << "What value would you like them initialized to?";
    cin >> init_value;
    
    my_array = creat_array(size, init_value);
    cout << "\n-----------------------" << endl;
    
    display(my_array, size);
    delete [] my_array; 
    
	return 0;
}
