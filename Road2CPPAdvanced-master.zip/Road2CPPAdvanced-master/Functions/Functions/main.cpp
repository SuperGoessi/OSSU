#include <stdio.h>
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <iomanip>
#include <string>

using namespace std;
const double pi {3.1415926};

double calc_area_circle(double radius);
void area_circle();
void volume_cylinder(); 
int add_numbers(int, int);

void pass_by_value1(int num);
void pass_by_value2(string s);
void pass_by_value3(vector<string> v);
void print_vector(vector<string> v);
void print_vector(vector<string> v);

double calc_cost(double base_cost, double tax_rate=0.06, double shipping = 3.5);
void greeting(string name, string prefix = "Mr.", string suffix = "");

void print(int);
void print(double);
void print(string);
void print(string, string);
void print(vector<string>); 

void print_array(const int arr[], size_t size);
void set_array(int arr[], size_t size, int value);

void scale_number(int &num);
void swap(int &a, int &b);
void print(const std::vector<int> &v);

int main()
{
    /*
    double num {};
    
    cout << "Enter a number (double): ";
    cin >> num;
    
    cout << "The sqrt of " << num << " is:" << sqrt(num) <<endl;
    cout << "The cubed root of " << num << " is: " << cbrt(num) << endl;
    
    cout << "The sine of " << num << " is: " << sin(num) << endl;
    cout << "The cosine of " << num << " is: " << cos(num) << endl;
    
    cout << "The ceil of " << num << " is: " << ceil(num) << endl;
    cout << "The floor of " << num << " is: " << floor(num) << endl;
    cout << "The round of " << num << " is: " << round(num) << endl;
    
    double power {};
    cout << "\nEnter a power to raise " << num << " to:";
    cin >> power;
    cout << num << " raised to the " << power << " power is: " << pow(num, power) << endl;
    cout << endl;
    
    int random_number {};
    size_t count {10};
    int min {1};
    int max {6};
    
    cout << "RAND_MAX on my system is: " << RAND_MAX << endl;
    srand(time(nullptr));
    
    for(size_t i{1}; i <= count; ++i)
    {
        random_number = rand() % max + min;
        cout << random_number << endl;
    }
	cout << endl;
    
    area_circle();
    volume_cylinder();
    cout << add_numbers(3, 4) << endl; 
    
    int num{10};
    cout << "num before calling pass_by_value1: " << num << endl;
    pass_by_value1(num);
    cout << "num after calling pass_by_value1: " << num << endl;
    
    int another_num {100};
    cout << "\nanother_num before calling pass_by_value1: " << another_num << endl;
    pass_by_value1(another_num);
    cout << "another_num after calling pass_by_value1: " << another_num << endl;
    
    string name {"Frank"};
    cout << "\nname before calling pass_by_value2: " << name << endl;
    pass_by_value2(name);
    cout << "name after calling pass_by_value2: " << name << endl;
    
    vector<string> stogges {"Larry", "Moe", "Curly"};
    cout << "\nstooges before calling pass_by_value3: ";
    print_vector(stogges);
    pass_by_value3(stogges);
    cout << "stooges after calling pass_by_value3: ";
    print_vector(stogges);
    
    double cost {0};
    cost = calc_cost(100.0, 0.08, 4.25);
    
    cout << fixed << setprecision(2);
    cout << "Cost is: " << cost << endl;
    
    cost = calc_cost(100.0, 0.08);
    cout << "Cost is: " << cost << endl;
    
    cost = calc_cost(200.0);
    cout << "Cost is: " << cost << endl;
    
    cout << endl;
    
    greeting("Glenn Jones", "Dr.", "M.D.");
    greeting("James Rogers", "Professor", "Ph.D.");
    
    int my_scores[] {100, 98, 90, 86, 84};
    
    print_array(my_scores, 5);
    set_array(my_scores, 5, 100);
    print_array(my_scores, 5);*/
    
    int number {1000};
    scale_number(number);
    cout << number << endl;
    
    int x {10}, y{20};
    cout << x << " " << y << endl;
    swap(x, y);
    cout << x << " " << y << endl;
    
    std::vector<int> data {1,2,3,4,5};
    print(data);
    
	return 0;
}

double calc_area_circle(double radius)
{
    return pi*radius*radius;
}

void area_circle()
{
    double radius {};
    cout << "\nENter the radius of the circle: ";
    cin >> radius;
    
    cout << "The area of a circle with radius " << radius << " is " << calc_area_circle(radius) << endl;
}

void volume_cylinder()
{
    double radius {};
    double height {};
    
     cout << "\nEnter the radius of the cylinder: ";
     cin >> radius;
     cout << "\nEnter the height of the cylinder: ";
     cin >> height;
     
     cout << "The volume of the cylinder is " << height*calc_area_circle(radius) << endl;
}

int add_numbers(int a, int b)
{
    return a + b;
}

void pass_by_value1(int num)
{
    num = 1000;
}

void pass_by_value2(string s)
{
    s = "Changed";
}

void pass_by_value3(vector<string> v)
{
    v.clear();
}

void print_vector(vector<string> v)
{
    for(auto s: v)
    {
        cout << s << " ";
    }
    cout << endl;
}

double calc_cost(double base_cost, double tax_rate, double shipping)
{
    return base_cost += (base_cost * tax_rate) + shipping;
}

void greeting(string name, string prefix, string suffix)
{
    cout << "Hello " << prefix + " " + name + " " + suffix << endl;
}

void print(int num)
{
    cout << "Printing int: " << num << endl;
}

void print(double num)
{
    cout << "Printing double: " << num << endl;
}

void print(string s)
{
    cout << "Printing string: " << s << endl;
}

void print(string s, string t)
{
    cout << "Printing 2 strings: " << s << " and " << t << endl;
}

void print(vector<string> v)
{
    cout << "Printing vector of strings: ";
    for(auto s: v)
    {
        cout << s + " ";
    }
    cout << endl;
}

void print_array(const int arr[], size_t size)
{
    for(size_t i {0}; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void set_array(int arr[], size_t size, int value)
{
    for(size_t i{0}; i < size; i++)
    {
        arr[i] = value;
    }
}

void scale_number(int &num)
{
    if(num>100)
    {
        num = 100;
    }
}

void swap(int &a, int &b)
{
    int temp=a;
    a = b;
    b= temp;
}

void print(const std::vector<int> &v)
{
    for(auto num:v)
        cout << num << endl;
}