#include <stdio.h>
#include <Player.h>
#include <iostream>

using namespace std;

void display_active_player() {
    cout << "Active players: " << Player::get_num_player() << endl;
}

int main(int argc, char **argv)
{
	display_active_player();
    Player hero{"Hero"};
    display_active_player();
	return 0;
}
