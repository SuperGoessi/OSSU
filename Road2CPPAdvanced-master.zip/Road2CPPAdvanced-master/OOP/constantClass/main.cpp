#include <stdio.h>
#include <iostream>
#include <string>

using namespace std;

class Player
{
private:
    std::string name;
    int health;
    int xp;
public:
    string get_name() const {
        return name;
    }
    void set_name(string name_val) {
        name = name_val;
    }
    
    Player();
    Player(string name_val);
    Player(string name_val, int health_val, int xp_val);
};

Player::Player()
    :Player{"None", 0, 0} {
        
    }
    
Player::Player(string name_val)
    :Player{name_val, 0, 0} {
        
    }

Player::Player(string name_val, int health_val, int xp_val)
    :name{name_val}, health{health_val}, xp{xp_val} {
        
    }
    
void display_player_name(const Player &pi) {
    cout << pi.get_name() << endl;
}
    
int main()
{
	const Player villian{"Villian", 100, 55};
    //villian.xp = 1000;
    
    Player Hear{"Hero", 100, 100};
    cout << Hear.get_name() << endl;
    
	return 0;
}
