#ifndef _PLAYER_H_
#define _PLAYER_H_

#include <string>
#include <iostream>
using namespace std;
class Player
{
private:
    string name;
    int health;
    int xp;
public:
    Player(){
        cout << "No args constructor caleed" << endl;
        name = "None";
        health = 100;
        xp = 3;
    }
    /*
    Player(string name){
        cout << "String arg constructor called" << endl;
    }*/
    
    Player(string name_val, int health_val, int xp_val){
        cout << "Three args constructor called" << endl;
        name = name_val;
        health = health_val;
        xp = xp_val;
    }
    
    Player(const Player &source);
    
    ~Player(){
        cout << "Destructor called for " << name << endl;
    }

    void talk(string text_to_say) {cout << name << "says " << text_to_say << endl;}
    bool is_dead();
    void set_name(string name_val) {
        name = name_val;
    }
    string get_name(){
        return name;
    }
};

#endif // _PLAYER_H_
