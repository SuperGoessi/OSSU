#include <iostream>
#include "Player.h"

using namespace std;

Player::Player(const Player &source)
    :name(source.name), health(source.health), xp(source.xp) {
        cout << "Copy constructor - made copy of: " << source.name << endl;
    }
