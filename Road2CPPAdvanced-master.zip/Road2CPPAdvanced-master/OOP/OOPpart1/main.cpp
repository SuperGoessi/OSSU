#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include "Account.h"
#include "Player.h"
using namespace std;

int main()
{
    /*
    Account frank_account;
    frank_account.name = "Frank's account";
    frank_account.balance = 5000.0;
    
    frank_account.deposit(1000.0);
    frank_account.withdraw(500.0);
    
    Player frank;
    frank.name = "Frank";
    frank.health = 100;
    frank.xp = 12;
	frank.talk("Hi, there");
    
    Player *enemy = new Player;
    (*enemy).name = "Enemy";
    (*enemy).health = 100;
    enemy->xp = 15;
    enemy->talk("I will destroy you!");
    Player frank;
    frank.talk("Good");
    
    Account frank_account;
    frank_account.set_name("Frank's account");
    frank_account.set_balance(1000.0);
    
    if(frank_account.deposit(200.0))
        cout << "Deposit OK" << endl;
    else
        cout << "Deposit Not allowed" << endl;
        
    if(frank_account.withdraw(500.0))
        cout << "Withdraw OK" << endl;
    else
        cout << " Not sufficient funds" << endl;
        
    if(frank_account.withdraw(1500.0))
        cout << "Withdraw OK" << endl;
    else
        cout << " Not sufficient funds" << endl;
        
    Player frank;
    //frank.name = "Fank";
    frank.talk("Hello there");*/
    
    Player hero;
    Player frankl {"Fank", 100, 13};
    frankl.set_name("Frank");
    cout << frankl.get_name() << endl;
	return 0;
}
