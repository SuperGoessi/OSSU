#include <stdio.h>
#include<iostream>
#include "Player.h"

using namespace std;

void display_player(Player p) {
    cout << "Name: " << p.get_name() << endl;
    cout << "Health: " << p.get_health() << endl;
    cout << "XP: " << p.get_xp() << endl;
}

int main()
{
	Player empty {"XXXXXXX", 100, 50};
    Player my_new_object {empty};
    
    display_player(empty);
    Player frank{"Frank"};
    Player villain {"Villain", 100, 65};
	return 0;
}
