#include "Player.h"
#include <iostream>

using namespace std;

Player::Player(string name_val, int health_val, int xp_val)
: name{name_val}, health{health_val}, xp{xp_val}
{
    cout << "Three args " + name << endl;
}

Player::~Player()
{
    cout << "Destructor for " + name << endl;
}

Player::Player(const Player &source)
    :name(source.name), health(source.health), xp(source.xp)
{
    cout << "Copy constructor - made copy of: " << source.name << endl;
}
