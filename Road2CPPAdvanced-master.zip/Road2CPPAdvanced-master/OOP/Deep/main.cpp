#include <stdio.h>
#include <iostream>

using namespace std;
class Deep {
private:
    int *data;
public:
    Deep(int d);
    Deep(const Deep &source);
    ~Deep();
};

Deep::Deep(const Deep &source)
{
    data = new int;
    *data = *source.data;
    cout << "Copy constructor - deep" << endl;
}

Deep::Deep(int d) {
    data = new int;
    *data = d;
}

Deep::~Deep() {
    delete data;
    cout << "Destructor freeing data:" << endl;
}

int main(int argc, char **argv)
{
	
	return 0;
}
