#include <iostream>
#include <cctype>
#include <cstring>
#include <string>

using namespace std;

int main()
{
    /*char first_name[20] {};
    char last_name[20] {};
    char full_name[50] {};
    char temp[50] {};*/
    
    //cout << first_name;
    
    /*cout << "Please enter your first name: ";
    cin >> first_name;
    
    cout << "Please enter your last name: ";
    cin >> last_name;
    cout << "------------------------------------" << endl;
    
    cout << "Hello, " << first_name << " your first name has " << strlen(first_name) << " characters" << endl;
    cout << "and your last name, " << last_name << " has " << strlen(last_name) << " characters" << endl;
    
    strcpy(full_name, first_name);
    strcat(full_name, " ");
    strcat(full_name, last_name);
    cout << "Your full name is " << full_name << endl;*/
    
   /* cout << "Enter your full name: ";
    cin.getline(full_name, 50);
    cout << "Your full name is " << full_name << endl;
    
    cout << "--------------------------------------" << endl;
    strcpy(temp, full_name);
    if(strcmp(temp, full_name) == 0)
        cout << temp << " and " << full_name << " are the same" << endl;
    else
        cout << temp << " and " << full_name << " are different" << endl;
    cout << "--------------------------------------" << endl;*/
    
    /*string s1;
    string s2 {"Frank"};
    string s3 {s2};
    string s4 {"Frank", 3};
    string s5 {s3, 0, 2};
    string s6 (3, 'X');
    
    string part1 {"C++"};
    string part2 {"is a powerful"};
    
    string sentence;
    sentence = part1 + " " + part2 + " language";
    cout << sentence << endl;
    
    for(char c:s2)
        cout << c << endl;
        
    cin >> s1;
    cout << s1 << endl;
    
    getline(cin, s1);
    cout << s1 << endl;
    
    getline(cin, s1, 'x');
    cout << s1 << endl;*/
    
    /*string s0;
    string s1 {"Apple"};
    string s2 {"Banana"};
    string s3 {"Kiwi"};
    string s4 {"apple"};
    string s5 {s1};
    string s6 {s1, 0, 3};
    string s7 (10, 'X');
    
    cout << s0 << endl;
    cout << s0.length() << endl;
    
    cout << "\nInitialization" << "\n-------------------" << endl;
    cout << "s1 is initialized to: " << s1 << endl;
    cout << "s2 is initialized to: " << s2 << endl;
    cout << "s3 is initialized to: " << s3 << endl;
    cout << "s4 is initialized to: " << s4 << endl;
    cout << "s5 is initialized to: " << s5 << endl;
    cout << "s6 is initialized to: " << s6 << endl;
    cout << "s7 is initialized to: " << s7 << endl;
    
    cout << "\nComparison" << "\n----------------------" << endl;
    cout << boolalpha;
    cout << s1 << " == " << s5 << ": " << (s1==s5) << endl;
    cout << s1 << " == " << s2 << ": " << (s1==s2) << endl;
    cout << s1 << " != " << s2 << ": " << (s1!=s2) << endl;
    cout << s2 << " < " << s1 << ": " << (s2 < s1) << endl;
    cout << s4 << " > " << s5 << ": " << (s4 > s5) << endl;*/
    
    string alphabet {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"};
    string key {"XZNLWEBGJHQDYVTKFUOMPCIASRxznlwebgjhqdyvtkfuompciasr"};
    
    cout << "Please enter a message: ";
    string secret_message {};
    getline(cin, secret_message);
    
    string encrypted_message {};
    cout << "Encrypting message..." <<endl;
    
    for(char c:secret_message)
    {
        size_t position = alphabet.find(c);
        if(position != string::npos)
        {
            char new_char {key.at(position)};
            encrypted_message += new_char;
        }
        else
        {
            encrypted_message += c;
        }
    }
    
    cout << "\nEncrypted message: " << encrypted_message << endl;
    
    string decrypted_message {};
    for(char a:encrypted_message)
    {
        size_t pos = key.find(a);
        if(pos != string::npos)
        {
            char n_char {alphabet.at(pos)};
            decrypted_message += n_char;
        }
        else
        {
            decrypted_message += a;
        }
    }
    cout << "\nDecrypted message: " << decrypted_message << endl;
    
    return 0;
}
