// Ex1_01.cpp
// A complete C++ program

#include<iostream>

using namespace std;

int main()
{
    int answer {42};

    std::cout << "The answer to life, the universe, and everything is "
              << answer
              << std::endl;
    return 0;
}

/* This is s
two lines comments */

/************
* This is a *
* over two lines. *
*************/
